# 法学论文语料库：独立安装说明

将 skill.zip 作为一个完整 ZIP 上传到你账号的 ChatGPT Skills 自定义技能上传入口。入口名称和可用性以账号界面为准，不要把 ZIP 当作普通知识文件上传。安装后选择“法学论文语料库”，在支持 Python 执行和技能文件访问的会话中使用。未实际在 ChatGPT 上传验证，安装包已通过脱离仓库的本地执行测试。

## 环境与内容

Python 3.10+，仅使用标准库；无需 Node.js、DeepSeek Harness、API Key 或联网。ZIP 只有 law-paper-writing/ 一个顶层技能目录、一个 SKILL.md。agents/openai.yaml 提供界面元数据，实际显示依平台支持而定。data/ 内含12个原始 JSONL 文件，共850条题录（847篇标准论文、3条笔谈/编者按），覆盖中国法学、比较法研究、法学研究、中外法学的2024—2026年记录。不要将850条均称为标准论文。

## 中文提问示例

- 使用 law-paper-writing，检索“离婚后未成年子女抚养费”，分别检索“抚养费”“离婚”“子女”和“亲属扶养”，区分直接与间接相关，列出真实题名、作者、年期和目录。
- 分析本库《法学研究》2025年的期刊样本，说明关键词及目录特征。
- 检索“亲属扶养”的真实论文框架，并将结果导出为 Markdown、CSV 和 JSONL，提供下载链接。

## 命令行

以下从技能目录执行；任何其他目录都可改用 scripts/lawcorpus.py 的绝对路径，数据仍按脚本位置定位。导出写当前工作目录的 output/，不修改技能数据。安装目录只读时，请在可写工作目录用绝对脚本路径导出。

```bash
python3 scripts/lawcorpus.py status
python3 scripts/lawcorpus.py search --query "抚养费" --mode phrase
python3 scripts/lawcorpus.py search --query "离婚后未成年子女抚养费" --limit 5
python3 scripts/lawcorpus.py frame --query "亲属扶养" --mode phrase --limit 3
python3 scripts/lawcorpus.py profile --journal "法学研究" --year-from 2025 --year-to 2025
python3 scripts/lawcorpus.py match --title "亲属扶养" --keywords "亲属扶养；身份伦理"
python3 scripts/lawcorpus.py export --query "亲属扶养" --mode phrase --format markdown --output output/亲属扶养.md
python3 scripts/lawcorpus.py export --query "亲属扶养" --mode phrase --format csv --output output/亲属扶养.csv
python3 scripts/lawcorpus.py export --query "亲属扶养" --mode phrase --format jsonl --output output/亲属扶养.jsonl
```

`--data-dir`（子命令之前）或 LAWCORPUS_DIR 可显式指定其他真实语料目录；通常不要设置。已有导出文件默认拒绝覆盖，明确授权替换后才使用 --overwrite。

## 证据和权利边界

题录来自现有 PDF 抽取，原始 PDF 未附带，不能声称核对出版原文。字段可能残缺，包括题名“7条之适用”；不得补造完整题名。ranked 允许部分词元命中，不等于语义相关；phrase 仅证明短语出现。现有“抚养费”短语未命中不代表该领域没有研究。“亲属扶养”是扩展主题，不能暗中替换“抚养”。目录和摘要保留原文，助手建议须另行标明。

原说明记载中外法学2024缺1、2、5期，2026非全年完整，少数期号经回填；不代表全量或最新期刊。LICENSE 适用于项目代码，不能替代论文作者与出版方的内容权利授权。没有发布到技能市场。
